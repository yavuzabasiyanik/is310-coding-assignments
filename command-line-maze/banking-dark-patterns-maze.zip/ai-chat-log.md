# AI Chat Log — Command Line Maze

I used Claude Code (Anthropic) to help build this assignment. The
banking/fintech dark patterns theme came from my own background, and
I asked Claude Code to help turn that idea into a working
command-line maze.
